/*
CMPT 270 Course material
Copyright (c) 2022
All rights reserved.

This document contains resources for homework assigned to students of
CMPT 270 and shall not be distributed without permission.  Posting this
file to a public or private website, or providing this file to a person
not registered in CMPT 270, constitutes Academic Misconduct, according
to the University of Saskatchewan Policy on Academic Misconduct.

Synopsis: Solution file for Assignment 1 Question 3
*/
public class a1q3
{
    public static void main(String[] args)
    {
        // Assignment weight - each assignment is 5%
        double asnWeight = 5.0;
        // Assignment variables - actual score as well as maximum possible score
        int asn1SCore = 42;
        int asn1Max = 49;
        int asn2Score = 42;
        int asn2Max = 45;
        int asn3Score = 42;
        int asn3Max = 42;
        int asn4Score = 19;
        int asn4Max = 22;
        int asn5Score = 27;
        int asn5Max = 38;
        int asn6Score = 22;
        int asn6Max = 38;
        int asn7Score = 67;
        int asn7Max = 73;

        // Assignments total percentage
        double assignments = asnWeight * asn1SCore / asn1Max + asnWeight * asn2Score / asn2Max + asnWeight * asn3Score / asn3Max + asnWeight * asn4Score / asn4Max
                + asnWeight * asn5Score / asn5Max + asnWeight * asn6Score / asn6Max + asnWeight * asn7Score / asn7Max;

        // Actual exercise scores - each assignment is out of 25
        int ex1 = 21;
        int ex2 = 18;
        int ex3 = 17;
        int ex4 = 18;
        int ex5 = 19;
        int ex6 = 13;
        int ex7 = 17;
        int ex8 = 19;
        int ex9 = 18;
        int ex10 = 22;

        // Exercises total percentage - out of total 250 possible marks
        double exercises = (ex1 + ex2 + ex3 + ex4 + ex5 + ex6 + ex7 + ex8 + ex9 + ex10) / 250.0;

        // Midterm score percentage
        double midterm = 83.2;

        // Final exam score percentage
        double finalExam = 94.1;

        // Calculate the total course grade
        double totalGrade = assignments + 20.0 * exercises + 20.0 * midterm / 100.0 + 25.0 * finalExam / 100.0;

        // Show results
        int courseDisplay = (int) Math.round(totalGrade);

        System.out.println("Student: Einstein, Albert");
        System.out.println("  Exercises:  " + ex1 + ", " + ex2 + ", " + ex3 + ", " + ex4 + ", " + ex5 + ", "
                + ex6 + ", " + ex7 + ", " + ex8 + ", " + ex9 + ", " + ex10);
        System.out.println("  Assignments:  " + asn1SCore + "/" + asn1Max + ", " + asn2Score + "/" + asn2Max + ", "
                + asn3Score + "/" + asn3Max + ", " + asn4Score + "/" + asn4Max + ", " + asn5Score + "/" + asn5Max + ", "
                + asn6Score + "/" + asn6Max + ", " + asn7Score + "/" + asn7Max);

        System.out.println("  Midterm:  " + midterm);
        System.out.println("  Final:  " + finalExam);
        System.out.println("Grade: " + courseDisplay);

    }
}

