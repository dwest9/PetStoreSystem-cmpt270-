/*
 CMPT 270 Course material
 Copyright (c) 2021
 All rights reserved.

 This document contains resources for homework assigned to students of
 CMPT 270 and shall not be distributed without permission.  Posting this
 file to a public or private website, or providing this file to a person
 not registered in CMPT 270, constitutes Academic Misconduct, according
 to the University of Saskatchewan Policy on Academic Misconduct.

 Synopsis: Solution file for Assignment 2 Question 2
*/

import java.util.Scanner;

/**
 * A2Q1: A Va Language Interpreter
 * This is a console application!
 */
public class a2q1
{

    /**
     Implements the Va language interpreter in Basic Java.
     @param HEAPSIZE: the number of doubles in the heap
     */

    public static void interpreter(int HEAPSIZE) {
        // the machine's memory model
        double register = 0.0;
        double[] heap = new double[HEAPSIZE];

        // variables for the command values
        String command;
        double value;
        int index;

        Scanner in = new Scanner(System.in);

        // the main interpreter loop
        do {
            // prompt for an input
            System.out.print(">> ");

            // read a command;
            command = in.next();

            // delay reading the argument until
            // we know which command was given
            if (command.equals("SET")) {
                register = in.nextDouble();
            }
            else if (command.equals("TELL")) {
                System.out.println(register);
            }
            else if (command.equals("LOAD")) {
                index = in.nextInt();
                register = heap[index];
            }
            else if (command.equals("STORE")) {
                index = in.nextInt();
                heap[index] = register;
            }
            else if (command.equals("ADD")) {
                value = in.nextDouble();
                register += value;
            }
            else if (command.equals("SUB")) {
                value = in.nextDouble();
                register -= value;
            }
            else if (command.equals("MUL")) {
                value = in.nextDouble();
                register *= value;
            }
            else if (command.equals("DIV")) {
                value = in.nextDouble();
                register /= value;
            }
            else if (command.equals("ADDI")) {
                index = in.nextInt();
                register += heap[index];
            }
            else if (command.equals("SUBI")) {
                index = in.nextInt();
                register -= heap[index];
            }
            else if (command.equals("MULI")) {
                index = in.nextInt();
                register *= heap[index];
            }
            else if (command.equals("DIVI")) {
                index = in.nextInt();
                register /= heap[index];
            }
            else if (command.equals("STATE")) {
                System.out.println("State:");
                System.out.println("  register = " + register);
                for (int i = 0; i < HEAPSIZE; i++) {
                    System.out.println("  heap[" + i + "] = " + heap[i]);
                }
            }
            else if (command.equals("HALT")) {
                // nothing specific except avoid the catch-all case below
            }
            else {
                String given = in.nextLine();
                System.out.println("Bad command: '" + command + given + "'");
                break;
            }
        } while (!command.equals("HALT"));
    }


    public static void main(String[] args) {
        // run the interpreter with a small heap
        interpreter(5);
    }

}
