/* **********************
 CMPT 270 Course material
 Copyright (c) 2022
 All rights reserved.

 This document contains resources for homework assigned to students of
 CMPT 270 and shall not be distributed without permission.  Posting this
 file to a public or private website, or providing this file to a person
 not registered in CMPT 270, constitutes Academic Misconduct, according
 to the University of Saskatchewan Policy on Academic Misconduct.

 Synopsis: Solution file for Assignment 2 Question 3
 ********************/

import java.util.Scanner;

/**
 * A number square rotation puzzle game
 */
public class a2q3
{

    /**
     * Displays a 3x3 square to the console
     * @param square: a 3x3 square containing only integers 1, 2, or 3 (Three of each integer)
     */
    public static void displaySquare(int[][] square)
    {
        for (int[] row : square)
        {
            for (int v : row)
            {
                System.out.print(v + " ");
            }
            System.out.println();
        }
    }


    /**
     * Checks if two given 3x3 squares have the same values in the same locations
     * @param sq1: a 3x3 square containing only integers 1, 2, or 3
     * @param sq2: a 3x3 square containing only integers 1, 2, or 3
     * @return true if the squares have the same values in the same locations, false otherwise
     */

    public static boolean squaresEqual(int[][] sq1, int[][] sq2)
    {
        for (int r = 0; r < 3; r++)
        {
            for (int c = 0; c < 3; c++)
            {
                if (sq1[r][c] != sq2[r][c])
                {
                    return false;
                }
            }
        }
        return true;
    }


    /**
     * Rotates a given sub-square in the left direction (counter-clockwise)
     */
    public static void rotateLeft(int[][] square, int subsquare)
    {
        int temp;

        switch (subsquare)
        {
            case 0:
                // rotate top left sub-square CCW
                temp = square[0][0]; // save top left
                square[0][0] = square[0][1];
                square[0][1] = square[1][1];
                square[1][1] = square[1][0];
                square[1][0] = temp;
                break;

            case 1:
                // rotate top right sub-square CCW
                temp = square[0][1]; // save top left
                square[0][1] = square[0][2];
                square[0][2] = square[1][2];
                square[1][2] = square[1][1];
                square[1][1] = temp;
                break;

            case 2:
                // rotate bottom left sub-square CCW
                temp = square[1][0]; // save top left
                square[1][0] = square[1][1];
                square[1][1] = square[2][1];
                square[2][1] = square[2][0];
                square[2][0] = temp;
                break;

            case 3:
                // rotate bottom left sub-square CCW
                temp = square[1][1]; // save top left
                square[1][1] = square[1][2];
                square[1][2] = square[2][2];
                square[2][2] = square[2][1];
                square[2][1] = temp;
                break;

            default:
                System.out.println("Sub-square index invalid");
        }
    }


    /**
     * Rotates a given sub-square in the right direction (clockwise)
     */
    public static void rotateRight(int[][] square, int subsquare)
    {

        int temp;

        switch (subsquare)
        {
            case 0:
                // rotate top left CW
                temp = square[0][0]; // save top left
                square[0][0] = square[1][0];
                square[1][0] = square[1][1];
                square[1][1] = square[0][1];
                square[0][1] = temp;
                break;

            case 1:
                // rotate top right CW
                temp = square[0][1]; // save top left
                square[0][1] = square[1][1];
                square[1][1] = square[1][2];
                square[1][2] = square[0][2];
                square[0][2] = temp;
                break;

            case 2:
                // rotate bottom left CW
                temp = square[1][0]; // save top left
                square[1][0] = square[2][0];
                square[2][0] = square[2][1];
                square[2][1] = square[1][1];
                square[1][1] = temp;
                break;

            case 3:
                // rotate bottom left CW
                temp = square[1][1]; // save top left
                square[1][1] = square[2][1];
                square[2][1] = square[2][2];
                square[2][2] = square[1][2];
                square[1][2] = temp;
                break;

            default:
                System.out.println("Sub-square index invalid");
        }

    }

    /**
     * Executes the rules of the game
     * @param square: the square that is manipulated by the user using console commands
     * @param goal:   the square the user is trying to reach as an end-goal
     */
    public static void playGame(int[][] square, int[][] goal)
    {
        // a string to use to check for valid commands
        String validDirections = "RL";

        String direction;
        int subSquareIndex;
        int totalMoves;

        // getting input from the console
        Scanner in = new Scanner(System.in);

        // variable for tracking move count
        totalMoves = 0;

        System.out.println("Number Square Rotation Game");

        // main game loop
        while (!squaresEqual(square, goal))
        {

            // show the square
            displaySquare(square);

            // loop until a valid move is entered
            // valid moves are a direction ('R' or 'L'), followed by the sub-square number (0-3)
            do
            {
                System.out.print("Enter move: ");
                direction = in.next();
                subSquareIndex = in.nextInt();
                // exit if valid
                if (validDirections.contains(direction) && subSquareIndex >= 0 && subSquareIndex < 4)
                {
                    break;
                }
                System.out.println("Not a valid move!!");
            } while (true);

            // perform the given move
            if (direction.equals("R"))
            {
                rotateRight(square, subSquareIndex);
                totalMoves++;
            } else if (direction.equals("L"))
            {
                rotateLeft(square, subSquareIndex);
                totalMoves++;
            } else
            {
                System.out.print("Somehow got an invalid move still");
            }
        }

        // Game has been completed and won
        displaySquare(square);
        System.out.println("You won!");
        System.out.println("Total moves: " + totalMoves);
    }


    public static void main(String[] args)
    {
        // The end goal square - row 1 has all 1's, row 2 has all 2's, row 3 has all 3's
        int[][] goal = {{1, 1, 1}, {2, 2, 2}, {3, 3, 3}};

        // a few different starting configurations
        int[][] start0 = {{1, 1, 2}, {3, 2, 2}, {3, 1, 3}};
        int[][] start1 = {{3, 1, 1}, {1, 3, 2}, {2, 3, 2}};
        int[][] start2 = {{3, 1, 2}, {1, 1, 2}, {2, 3, 3}};
        int[][] start3 = {{3, 3, 3}, {1, 1, 1}, {2, 2, 2}};

        // play the game just once!
        playGame(start1, goal);
    }
}
